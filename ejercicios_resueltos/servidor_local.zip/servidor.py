import socket
from threading import Thread
from time import sleep

# Declaramos las variables que vamos a usar
HOST = socket.gethostbyname(socket.gethostname())
PORT = 65432
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
i = 0

# Este texto nos permitirá escuchar varias conexiones simultáneas
# creando variables con nombres diferentes usando un índice
text = """
conn_*-*-*, addr_*-*-* = s.accept()
Thread(target=connect, args=(i, )).start()
with conn_*-*-*:
    print('Connected by', addr_*-*-*)
    while True:
        try:
            data_*-*-* = conn_*-*-*.recv(1024)
        except:
            exit(0)
        if data_*-*-*:
            print(data_*-*-*)
        conn_*-*-*.sendall(data_*-*-*)
        conn_*-*-*.sendall(b'The other side orders to stop')
        sleep(1)
"""


# Definimos la función que se ejecutará en un thread para usar
# el texto anterior
def connect(sub):
    global i
    i += 1
    try:
        exec(text.replace("*-*-*", str(sub)))
    except:
        exit(0)


# Creamos la función principal
def main_function():
    with s:  # Abrimos el socket
        s.bind((HOST, PORT))  # Creamos un socket de escucha en un puerto y host
        s.listen(5)  # Escuchamos hasta 5 conexiones simultáneas
        conn, addr = s.accept()  # Aceptamos la conexión cuando venga la primera
        Thread(target=connect, args=(i, )).start() # Creamos un thread para seguir escuchaando mientras corre el programa
        with conn:  # Abrimos la conexión
            print('Connected by', addr)
            while True:  # Creamos un bucle para la comunicación
                try:
                    data = conn.recv(1024)
                except:  # Si se cierra la conexión, salimos del bucle
                    exit(0)
                if data:  # Si hay datos, los imprimimos
                    print(data)
                # Enviamos un archivo al otro lado
                conn.sendall(open("EjemploArchivoParaEnviar.txt", "rb").read())
                conn.sendall(b'<stop>')  # Enviamos un mensaje de final, para que sepa que el mensaje ha finalizado
                sleep(1)


if __name__ == '__main__':
    main_function()  # Corremos la función principal
