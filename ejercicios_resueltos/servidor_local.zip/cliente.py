import socket

# Creamos el socket y las variables que vamos a usar
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HOST = socket.gethostbyname(socket.gethostname())
PORT = 65432


# Creamos la función principal
def listening():
    global s
    with s:  # Abrimos el socket
        s.connect((HOST, PORT))  # Nos conectamos a un host y un puerto
        s.sendall(b'Hello, world')  # Enviamos un mensaje
        while True:  # Creamos un bucle para la comunicación
            try:
                data = b''
                while True:  # Creamos un bucle para la recepción de datos
                    recvfile = s.recv(4096)  # De cada vez recivimos 4096 bytes
                    if recvfile == b'<stop>':  # Si recibimos un mensaje de final, salimos del bucle
                        break
                    data = recvfile + data  # Añadimos lo que hemos recibido al mensaje total
                if data:  # Si hay datos, los imprimimos
                    print(data)
            except:  # Si se cierra la conexión, salimos del bucle
                break


if __name__ == '__main__':
    listening()  # Corremos la función principal
