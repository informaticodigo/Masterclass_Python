import pygame

pygame.init()  # Inicializa el modulo pygame

size = 1300, 700
screen = pygame.display.set_mode(size)  # Damos tamaño a la ventana
pygame.display.set_caption("Juego en python")  # Titulo de la ventana
width, height = 1300, 700
speed = [2, 2]
white = 255, 255, 255

simbolo = pygame.image.load("pelota.jpg")  # Cargamos la imagen
simbolorect = simbolo.get_rect()           # Obtenemos el rectangulo de la imagen

myfont = pygame.font.SysFont('Arial', 30)  # Obtenemos una fuente para el marcador

bate = pygame.image.load("bate.jpg")
baterect = bate.get_rect()

baterect.move_ip(400, 260)

tocados = 0
scoreu = 0
scoreg = 0

run = True
while run:
    pygame.time.delay(2)  # Espera un tiempo para no quemar la CPU
    for event in pygame.event.get():
        if event.type == pygame.QUIT: run = False
    keys = pygame.key.get_pressed()
    # Movemos el rectángulo de coordenadas del bate con los controles
    if keys[pygame.K_UP]:
        baterect = baterect.move(0, -1)
    if keys[pygame.K_DOWN]:
        baterect = baterect.move(0, 1)

    # Compruebo si hay colisión
    if baterect.colliderect(simbolorect):
        tocados += 1
        speed[0] = -speed[0]

    if simbolorect.left < 0:
        scoreg += 1

    if tocados >= 35:
        scoreu += 1
        tocados = 0


    score = (str(scoreu) + " - " + str(scoreg))

    # Establecemos el movimiento de la pelota por default
    simbolorect = simbolorect.move(speed)
    if simbolorect.left < 0 or simbolorect.right > width:
        speed[0] = -speed[0]
    if simbolorect.top < 0 or simbolorect.bottom > height:
        speed[1] = -speed[1]

    # Aquí hay un código para hacer que las velocidades sean dinámicas
    '''
    if (scoreg - scoreu) >= 10:
        speed = [1, 1]
    elif (scoreu - scoreg) >= 10:
        speed = [3, 3]
    elif (scoreu - scoreg) >= 25:
        speed = [4, 4]
    elif (scoreg - scoreu) <= 10 and (scoreu - scoreg) <= 10
    '''
    screen.fill(white)  # Pinta el fondo de la pantalla de blanco
    marcador = myfont.render(score, False, (0, 0, 0))  # Crea/Actualiza el marcador
    screen.blit(marcador, (0, 0))     # Pinta el marcador en la pantalla
    screen.blit(simbolo, simbolorect) # Posiciona la pelota en la pantalla
    screen.blit(bate, baterect)       # Posiciona el bate en la pantalla
    pygame.display.flip()

pygame.quit()
